const $=(s,p=document)=>p.querySelector(s);const $$=(s,p=document)=>[...p.querySelectorAll(s)];
window.addEventListener('load',()=>setTimeout(()=>$('.loader')?.classList.add('hide'),450));
$('.menu')?.addEventListener('click',()=>$('.links')?.classList.toggle('open'));
$$('.links a').forEach(a=>a.addEventListener('click',()=>$('.links')?.classList.remove('open')));
const io=new IntersectionObserver(entries=>entries.forEach(e=>{if(e.isIntersecting){e.target.classList.add('visible');if(e.target.classList.contains('stat')) animateStat(e.target)}}),{threshold:.18});$$('.reveal,.stat').forEach(el=>io.observe(el));
function animateStat(el){const n=el.querySelector('[data-count]');if(!n||n.dataset.done)return;n.dataset.done=1;const target=+n.dataset.count;let cur=0;const step=Math.max(1,Math.ceil(target/55));const suffix=n.dataset.suffix||'';const t=setInterval(()=>{cur+=step;if(cur>=target){cur=target;clearInterval(t)}n.textContent=cur+suffix},20)}
$$('.faq-q').forEach(q=>q.addEventListener('click',()=>q.parentElement.classList.toggle('open')));
$$('[data-filter]').forEach(btn=>btn.addEventListener('click',()=>{const f=btn.dataset.filter;$$('[data-filter]').forEach(b=>b.classList.remove('active'));btn.classList.add('active');$$('.product').forEach(card=>{card.style.display=f==='all'||card.dataset.cat===f?'block':'none'})}));
const lb=$('.lightbox'), lbImg=$('.lightbox img');$$('.gallery-item img').forEach(img=>img.addEventListener('click',()=>{if(lb&&lbImg){lbImg.src=img.src;lb.classList.add('show')}}));$('.close-lightbox')?.addEventListener('click',()=>lb.classList.remove('show'));lb?.addEventListener('click',e=>{if(e.target===lb)lb.classList.remove('show')});
function waUrl(msg){return `https://wa.me/918770539841?text=${encodeURIComponent(msg)}`}
$$('[data-wa]').forEach(el=>el.href=waUrl(el.dataset.wa));
$('#contactForm')?.addEventListener('submit',e=>{e.preventDefault();const fd=new FormData(e.target);const msg=`Hello Funk Casual Luxury, my name is ${fd.get('name')}. Phone: ${fd.get('phone')}. I am interested in ${fd.get('interest')}. Message: ${fd.get('message')}`;window.open(waUrl(msg),'_blank')});
