# Funk Casual Luxury Website

Premium 5-page static website for FUNK CASUAL LUXURY.

## Pages
- index.html
- about.html
- collections.html
- gallery.html
- contact.html

## Deploy
Upload all files to GitHub repository and import the repo in Vercel. No build command needed.
